Hello, iOS
==========

This sample is the application that will be built at the end of the [Getting Started](/guides/ios/getting_started/hello,_iOS/) guides.

There are two seperate folders containing a solution. **Hello.iOS** is the single view application that will be producted at the end of the [Hello, iOS Quickstart](/guides/ios/getting_started/hello,_iOS/hello,iOS_quickstart/), and **Hello.iOS_MultiScreen** is the two screen application produced at the end of the [Hello, iOS Multiscreen Quickstart](/guides/ios/getting_started/hello,_iOS_multiscreen/hello,_iOS_multiscreen_quickstart/).

Written By
==========
Amy Burns - For Documentation usage.

